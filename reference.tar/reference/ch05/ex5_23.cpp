#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main() 
{
    int i, j; 
    cin >> i >> j;
    cout << i / j << endl;
 
    return 0;
}
